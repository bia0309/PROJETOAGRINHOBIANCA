function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
// Variáveis do jogo
let arvores = [];
let recursos = 10;
let tempo = 0;
let estadoJogo = "jogando"; // "jogando" ou "gameover"
let sementesDisponiveis = 3;

function setup() {
  createCanvas(800, 600);
  textSize(16);
}

function draw() {
  background(135, 206, 235); // Céu azul
  
  // Desenhar grama
  fill(34, 139, 34);
  rect(0, height - 50, width, 50);
  
  // Atualizar e desenhar árvores
  for (let i = arvores.length - 1; i >= 0; i--) {
    arvores[i].atualizar();
    arvores[i].mostrar();
    
    // Remover árvores mortas
    if (arvores[i].saude <= 0) {
      arvores.splice(i, 1);
    }
  }
  
  // Mostrar informações do jogo
  fill(0);
  text(`Recursos: ${recursos}`, 20, 30);
  text(`Sementes: ${sementesDisponiveis}`, 20, 50);
  text(`Árvores: ${arvores.length}`, 20, 70);
  text(`Tempo: ${floor(tempo/60)}`, 20, 90);
  
  // Passar o tempo
  tempo += 0.1;
  
  // Gerar sementes aleatoriamente
  if (random() < 0.005) {
    sementesDisponiveis++;
  }
  
  // Verificar condições de game over
  if (recursos <= 0 && sementesDisponiveis <= 0 && arvores.length === 0) {
    estadoJogo = "gameover";
  }
  
  // Tela de game over
  if (estadoJogo === "gameover") {
    fill(0, 0, 0, 150);
    rect(0, 0, width, height);
    fill(255);
    textSize(32);
    text("Game Over", width/2 - 80, height/2 - 30);
    textSize(20);
    text(`Você cultivou ${floor(tempo/60)} unidades de tempo`, width/2 - 150, height/2 + 10);
    text("Clique para recomeçar", width/2 - 100, height/2 + 50);
    textSize(16);
  }
}

function mousePressed() {
  if (estadoJogo === "gameover") {
    // Reiniciar jogo
    arvores = [];
    recursos = 10;
    tempo = 0;
    sementesDisponiveis = 3;
    estadoJogo = "jogando";
    return;
  }
  
  // Verificar se o clique foi na grama
  if (mouseY > height - 50) {
    // Plantar nova árvore se tiver sementes
    if (sementesDisponiveis > 0) {
      arvores.push(new Arvore(mouseX, mouseY));
      sementesDisponiveis--;
    }
  } else {
    // Verificar se clicou em uma árvore para interagir
    for (let arvore of arvores) {
      if (dist(mouseX, mouseY, arvore.x, arvore.y - arvore.tamanho/2) < arvore.tamanho/2) {
        if (arvore.estado === "madura" && recursos > 0) {
          // Colher frutas
          recursos += 5;
          arvore.estado = "adulta";
          arvore.tempoFrutas = 0;
        } else if (recursos > 0) {
          // Regar a árvore
          arvore.saude += 10;
          recursos--;
        }
      }
    }
  }
}

class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 20;
    this.saude = 100;
    this.estado = "muda"; // "muda", "crescendo", "adulta", "madura"
    this.tempoCrescimento = 0;
    this.tempoFrutas = 0;
  }
  
  atualizar() {
    this.tempoCrescimento += 0.1;
    
    // Diminuir saúde gradualmente
    this.saude -= 0.02;
    
    // Atualizar estados de crescimento
    if (this.estado === "muda" && this.tempoCrescimento > 30) {
      this.estado = "crescendo";
    } else if (this.estado === "crescendo" && this.tempoCrescimento > 60) {
      this.estado = "adulta";
    } else if (this.estado === "adulta") {
      this.tempoFrutas += 0.1;
      if (this.tempoFrutas > 40) {
        this.estado = "madura";
      }
    }
    
    // Aumentar tamanho conforme cresce
    if (this.estado === "muda") {
      this.tamanho = 20 + this.tempoCrescimento / 3;
    } else if (this.estado === "crescendo") {
      this.tamanho = 30 + (this.tempoCrescimento - 30) / 2;
    } else if (this.estado === "adulta" || this.estado === "madura") {
      this.tamanho = 45;
    }
  }
  
  mostrar() {
    // Desenhar tronco
    fill(139, 69, 19);
    rect(this.x - 5, this.y - this.tamanho, 10, this.tamanho);
    
    // Desenhar copa da árvore
    if (this.estado === "muda") {
      fill(0, 100, 0);
    } else if (this.estado === "crescendo") {
      fill(34, 139, 34);
    } else if (this.estado === "adulta") {
      fill(0, 100, 0);
    } else if (this.estado === "madura") {
      fill(0, 200, 0);
    }
    
    ellipse(this.x, this.y - this.tamanho, this.tamanho, this.tamanho);
    
    // Desenhar frutas se estiver madura
    if (this.estado === "madura") {
      fill(255, 0, 0);
      ellipse(this.x - 10, this.y - this.tamanho - 5, 8, 8);
      ellipse(this.x + 10, this.y - this.tamanho + 5, 8, 8);
      ellipse(this.x, this.y - this.tamanho - 15, 8, 8);
    }
    
    // Mostrar barra de saúde
    fill(255, 0, 0);
    rect(this.x - 20, this.y - this.tamanho - 10, 40, 5);
    fill(0, 255, 0);
    rect(this.x - 20, this.y - this.tamanho - 10, map(this.saude, 0, 100, 0, 40), 5);
  }
}